# pepit installation
install.packages("pepit_1.0.tar.gz", type="source", REPOS=NULL)
